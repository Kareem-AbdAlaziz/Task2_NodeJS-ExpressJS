const express = require('express');
const router = express.Router();
const controller = require('../controllers/productController');
const { isAuthenticated } = require('../middleware/authMiddleware');

router.get('/', isAuthenticated, controller.getAllProducts);
router.get('/new', isAuthenticated, controller.showCreateForm);
router.post('/', isAuthenticated, controller.createProduct);
router.get('/:id', isAuthenticated, controller.getProductDetails);
router.get('/edit/:id', isAuthenticated, controller.showEditForm);
router.put('/:id', isAuthenticated, controller.updateProduct);
router.delete('/:id', isAuthenticated, controller.deleteProduct);

module.exports = router;
